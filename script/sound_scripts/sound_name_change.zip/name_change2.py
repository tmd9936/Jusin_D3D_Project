from pathlib import Path
import os

f = open(".\sound_name2.txt", 'r')
lines = f.readlines()

index = 1

sound_file_list = os.listdir('./out/')

sound_file_list.sort(key=lambda x: int(x.split('.')[0]))

for fn in sound_file_list:
    print(fn)

def get_oldName(index):
    result = str(index)
    while (len(result) < 3):
        result = '0' + result
    return result

for line in lines:
    new_name = line.split('\t')[1]
    old_name = sound_file_list[index -1]
    # path = Path('./out/' + str(old_name)  + '.ogg')  
    # path.rename('./out/' + str(new_name) + '.ogg')

    os.rename('./out/' + str(old_name), './out/' + str(new_name) + '.ogg')
    index += 1