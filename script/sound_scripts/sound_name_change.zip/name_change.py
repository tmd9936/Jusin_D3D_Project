from pathlib import Path
import os

f = open(".\sound_name.txt", 'r')
lines = f.readlines()

index = 1

def get_oldName(index):
    result = str(index)
    while (len(result) < 3):
        result = '0' + result
    return result

for line in lines:
    new_name = line.split('\t')[1]
    old_name = get_oldName(index)
    # path = Path('./out/' + str(old_name)  + '.ogg')  
    # path.rename('./out/' + str(new_name) + '.ogg')

    os.rename('./out/' + str(old_name)  + '.ogg', './out/' + str(new_name) + '.ogg')
    index += 1